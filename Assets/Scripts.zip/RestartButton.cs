using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartButton : MonoBehaviour
{
    public void StartGame()
    {
        SceneManager.LoadScene("CubeDrop");
    }
}