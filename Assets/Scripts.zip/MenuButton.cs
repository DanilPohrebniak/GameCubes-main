using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuButton : MonoBehaviour
{
    public void GoToMainMenu()
    {
        Debug.Log("Кнопка нажата, загружаю сцену Main");
        SceneManager.LoadScene("Main");
    }
}